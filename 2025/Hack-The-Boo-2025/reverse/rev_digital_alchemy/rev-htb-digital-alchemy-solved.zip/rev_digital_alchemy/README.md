# HTB Digital Alchemy - Solved

## Quick Start
```bash
# Extract and run
unzip rev-htb-digital-alchemy-solved.zip
cd rev_digital_alchemy/

# Run the solver
python3 solve.py

# Verify with binary (requires Linux)
docker run --rm --platform=linux/amd64 \
  -v "$(pwd)":/chal -w /chal \
  ubuntu:22.04 bash -lc "./athanor && cat gold.txt"
```

## Files Included
- `athanor` - Original challenge binary
- `lead.txt` - Input file with encrypted data
- `gold.txt` - Output file with decrypted flag
- `solve.py` - Complete solver script
- `analyze.py` - Analysis and debugging script
- `WRITEUP.md` - Detailed technical writeup

## Flag
```
HTB{Sp1r1t_0f_Th3_C0d3_Aw4k3n3d}
```

## Key Technical Details
- LCG decryption with 32-bit arithmetic
- Anti-debugging bypass (time checks)
- Off-by-one bug fix in payload processing
- Complete algorithm reverse engineering

See `WRITEUP.md` for full technical details.
