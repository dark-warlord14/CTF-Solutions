# HTB Digital Alchemy - Technical Writeup

## Challenge Overview
**Challenge Name:** Digital Alchemy
**Platform:** HackTheBox (Reversing)
**Flag Format:** HTB{...}
**Difficulty:** Medium

The binary `athanor` implements a digital "alchemist" that processes `lead.txt` to produce `gold.txt` containing the flag. The program includes anti-debugging time checks and amateur implementation bugs that must be bypassed.

## Files Analysis

### Binary Analysis
```bash
file athanor
# ELF 64-bit LSB pie executable, x86-64, version 1 (SYSV), dynamically linked

strings athanor | grep -E "(lead|gold|MTRLLEAD|USMWO|Initializing|Incantation)"
# MTRLLEAD
# USMWO[]\iN[QWRYdqXle[i_bm^aoc
# lead.txt
# gold.txt
# Initializing the Athanor...
# Incantation mismatch...
# The Athanor glows brightly...
```

### lead.txt Structure
```
Offset  Description
0-7     Magic header: "MTRLLEAD"
8-11    4-byte big-endian state seed (0x972cffbc)
12-40   29-byte incantation data
41-47   7-byte encrypted secret
48-74   26-byte encrypted flag data
```

## Algorithm Reconstruction

### 1. Header Validation
- Reads `lead.txt` in binary mode
- Verifies 8-byte magic header "MTRLLEAD"
- Extracts 4-byte big-endian state variable: `var_e8 = 0x972cffbc`

### 2. Anti-Debugging Time Checks
```c
// First time check - affects var_f4
if (time_diff > 2) var_f4 = 0xdead;
else var_f4 = 0x214f;  // Correct value

// Second time check - affects var_10
if (time_diff > 2) var_10 = 0xdead;
else var_10 = sum_of_incantation_bytes;  // Correct value
```

### 3. Incantation Decoding (First Transform)
Target string: `USMWO[]\iN[QWRYdqXle[i_bm^aoc` (29 bytes)

For each byte i in 0..28:
```c
byte var_51 = 0x40;  // '@'
var_8f = (var_51 + i) & 0xff;
var_8e = ((input_byte + var_8f) ^ var_51) & 0xff;
result = (var_8e % 127) + 1;
var_10 += input_byte;  // Accumulate sum
```

### 4. Secret Decryption (LCG-based XOR)
```c
// Linear Congruential Generator parameters
const uint32_t MODULUS = 0x26688d;
const uint32_t MULTIPLIER = 0x214f;  // var_f4 (anti-debug bypass)
const uint32_t INCREMENT = var_10;    // Sum from incantation

// State update (32-bit arithmetic)
state = ((MULTIPLIER * state) + INCREMENT) % MODULUS;

// XOR with lower 4 bits
output_byte = input_byte ^ (state & 0xf);
```

## Implementation Bugs Fixed

### Bug 1: Off-by-One Error
- Binary allocates 40 bytes but copies only 7 bytes (`size-1`)
- **Fix:** Process entire encrypted payload (33 bytes total)

### Bug 2: 32-bit Overflow
- LCG state updates must use 32-bit arithmetic before modulo
- **Fix:** Ensure all operations are 32-bit: `(a * b) & 0xffffffff`

## Solver Implementation

```python
def decrypt_lead():
    with open('lead.txt', 'rb') as f:
        data = f.read()

    # Validate header
    assert data.startswith(b'MTRLLEAD')

    # Extract state and advance pointer
    ptr = 8
    state = int.from_bytes(data[ptr:ptr+4], 'big') & 0xffffffff
    ptr += 4

    # First transform length (29 bytes)
    first_len = 29
    var_10 = sum(data[ptr:ptr+first_len]) & 0xffffffff
    ptr += first_len

    # Decrypt entire remaining data
    encrypted = data[ptr:]
    result = bytearray()

    for byte_val in encrypted:
        # LCG update (32-bit)
        state = ((0x214f * (state & 0xffffffff)) & 0xffffffff)
        state = (state + (var_10 & 0xffffffff)) & 0xffffffff
        state = state % 0x26688d  # Remainder after 32-bit division

        # XOR with lower 4 bits
        result.append(byte_val ^ (state & 0xf))

    return bytes(result).decode('latin-1').rstrip('\x0c')

flag = decrypt_lead()
print(f"HTB{{{flag}}}")
```

## Verification

### Docker Execution
```bash
docker run --rm --platform=linux/amd64 \
  -v "$(pwd)":/chal -w /chal \
  ubuntu:22.04 bash -lc "./athanor && cat gold.txt"
```

### Results
- **7-byte preview:** `HTB{Sp1`
- **Full decryption:** `HTB{Sp1r1t_0f_Th3_C0d3_Aw4k3n3d}`

## Key Technical Insights

1. **32-bit Arithmetic:** Critical for LCG state transitions
2. **Anti-Debug Bypass:** Use correct values (0x214f, calculated sum) not fail values (0xdead)
3. **Complete Payload:** Process entire encrypted section, not just 7 bytes
4. **Latin-1 Decoding:** Handle non-ASCII characters in flag

## Tools Used
- `radare2`: Binary analysis and disassembly
- `Docker`: Linux environment for ELF execution
- `Python`: Algorithm implementation and verification
- `strings`: String extraction
- `hexdump`: Data structure analysis

## Flag
```
HTB{Sp1r1t_0f_Th3_C0d3_Aw4k3n3d}
```
